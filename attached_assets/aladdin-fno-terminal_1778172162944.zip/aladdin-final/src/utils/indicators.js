// ─── Technical Indicators & Pattern Detection ─────────────────────────────
// Implements ALL patterns from all-patterns_pine.txt (Pine Script v4 logic)
// + generateSignal used by AI Signals page

// ─── Math helpers ────────────────────────────────────────────────────────
export const sma  = (arr, n) => arr.map((_,i,a) => i<n-1?null : a.slice(i-n+1,i+1).reduce((s,v)=>s+v,0)/n);
export const ema  = (arr, n) => { const k=2/(n+1); return arr.reduce((acc,v,i)=>{ acc.push(i===0?v:v*k+acc[i-1]*(1-k)); return acc; },[]); };
export const stdev= (arr, n) => arr.map((_,i,a) => { if(i<n-1) return null; const sl=a.slice(i-n+1,i+1),mn=sl.reduce((s,v)=>s+v,0)/sl.length; return Math.sqrt(sl.reduce((s,v)=>s+(v-mn)**2,0)/sl.length); });

export function rsi(prices, n=14) {
  const chg = prices.map((v,i)=>i===0?0:v-prices[i-1]);
  return prices.map((_,i)=>{
    if(i<n) return null;
    const g=chg.slice(i-n+1,i+1).filter(x=>x>0), l=chg.slice(i-n+1,i+1).filter(x=>x<0).map(Math.abs);
    const ag=g.length?g.reduce((s,v)=>s+v,0)/n:0, al=l.length?l.reduce((s,v)=>s+v,0)/n:0;
    return al===0?100:100-100/(1+ag/al);
  });
}

export function macd(prices, fast=12, slow=26, signal=9) {
  const ef=ema(prices,fast), es=ema(prices,slow);
  const line=ef.map((v,i)=>v-es[i]);
  const sig=ema(line,signal);
  return { line, signal:sig, hist:line.map((v,i)=>v-sig[i]) };
}

export function bb(prices, n=20, mult=2) {
  const sm=sma(prices,n), sd=stdev(prices,n);
  return prices.map((_,i)=>({ upper:sm[i]?sm[i]+mult*sd[i]:null, mid:sm[i], lower:sm[i]?sm[i]-mult*sd[i]:null }));
}

export function stochastic(highs, lows, closes, kPeriod=14, dPeriod=3) {
  const k = closes.map((_,i)=>{
    if(i<kPeriod-1) return null;
    const sl=highs.slice(i-kPeriod+1,i+1), ll=lows.slice(i-kPeriod+1,i+1);
    const hi=Math.max(...sl), lo=Math.min(...ll);
    return hi===lo?50:(closes[i]-lo)/(hi-lo)*100;
  });
  const kArr = k.filter(v=>v!==null);
  const d = ema(kArr, dPeriod);
  return { k, d };
}

export function atr(ohlcv, n=14) {
  if (!ohlcv||ohlcv.length<2) return 0;
  const trs = ohlcv.slice(1).map((c,i)=>{
    const p=ohlcv[i];
    return Math.max(c.high-c.low, Math.abs(c.high-(p.close||p.c||0)), Math.abs(c.low-(p.close||p.c||0)));
  });
  return trs.slice(-n).reduce((s,v)=>s+v,0)/Math.min(n,trs.length);
}

export function vwap(ohlcv) {
  let cumVol=0, cumPV=0;
  return ohlcv.map(c => {
    const typical=(c.high+c.low+c.close)/3;
    cumPV+=typical*(c.vol||1); cumVol+=(c.vol||1);
    return cumVol?cumPV/cumVol:typical;
  });
}

// ─── Pine Script pattern detection ──────────────────────────────────────
// Exact port of all-patterns_pine.txt Pine Script v4 logic
// C_ prefix matches Pine Script variable names

export function detectAllPatterns(ohlcv) {
  if (!ohlcv || ohlcv.length < 5) return [];
  const L = ohlcv.length;
  const results = [];

  // Helper references
  const c = ohlcv[L-1], p1 = ohlcv[L-2], p2 = ohlcv[L-3], p3 = ohlcv[L-4];
  const C_BodyHi  = v => Math.max(v.close, v.open);
  const C_BodyLo  = v => Math.min(v.close, v.open);
  const C_Body    = v => C_BodyHi(v)-C_BodyLo(v);
  const C_UpShadow= v => v.high-C_BodyHi(v);
  const C_DnShadow= v => C_BodyLo(v)-v.low;
  const C_Range   = v => v.high-v.low;
  const C_WhiteBody = v => v.close>v.open;
  const C_BlackBody = v => v.close<v.open;

  const bodyAvg = ohlcv.slice(-15).reduce((s,v)=>s+C_Body(v),0)/15;
  const C_SmallBody = v => C_Body(v) < bodyAvg;
  const C_LongBody  = v => C_Body(v) > bodyAvg;
  const C_HasUp  = v => C_UpShadow(v) > 0.05*C_Body(v);
  const C_HasDn  = v => C_DnShadow(v) > 0.05*C_Body(v);
  const C_NoUp   = v => C_UpShadow(v) < 0.05*C_Body(v);
  const C_NoDn   = v => C_DnShadow(v) < 0.05*C_Body(v);
  const C_IsDojiBody = v => C_Range(v)>0 && C_Body(v)<=C_Range(v)*0.05;
  const C_ShadowEq   = v => Math.abs(C_UpShadow(v)-C_DnShadow(v))/Math.max(C_DnShadow(v),0.001)*100 < 100;
  const C_Doji       = v => C_IsDojiBody(v) && C_ShadowEq(v);
  const gapUp  = (a,b) => C_BodyLo(b) > C_BodyHi(a);
  const gapDn  = (a,b) => C_BodyHi(b) < C_BodyLo(a);

  // ── BULLISH PATTERNS ──────────────────────────────────────────────────

  // Marubozu White: long white body, no shadows
  if (C_WhiteBody(c) && C_LongBody(c) && C_NoUp(c) && C_NoDn(c))
    results.push({ name:'Marubozu White', side:'BUY', score:82, desc:'Strong bullish candle with no shadows — full momentum' });

  // Hammer: small body at top, long lower shadow
  if (C_SmallBody(c) && C_DnShadow(c)>=2*C_Body(c) && C_UpShadow(c)<=0.1*C_Body(c) && L>1 && p1.close<p1.open)
    results.push({ name:'Hammer', side:'BUY', score:76, desc:'Reversal at support — bulls rejected the sell-off' });

  // Inverted Hammer
  if (C_SmallBody(c) && C_UpShadow(c)>=2*C_Body(c) && C_DnShadow(c)<=0.1*C_Body(c))
    results.push({ name:'Inverted Hammer', side:'BUY', score:68, desc:'Potential bullish reversal — watch for confirmation' });

  // Piercing
  if (p1&&C_BlackBody(p1)&&C_LongBody(p1)&&C_WhiteBody(c)&&c.open<p1.low&&c.close>(C_BodyHi(p1)+C_BodyLo(p1))/2&&c.close<p1.open)
    results.push({ name:'Piercing Line', side:'BUY', score:74, desc:'Bullish reversal — closes above midpoint of prior red candle' });

  // Bullish Engulfing
  if (p1&&C_BlackBody(p1)&&C_WhiteBody(c)&&c.open<=p1.close&&c.close>=p1.open)
    results.push({ name:'Bullish Engulfing', side:'BUY', score:80, desc:'Bears fully engulfed — strong bullish momentum shift' });

  // Tweezer Bottom
  if (p1&&Math.abs(c.low-p1.low)<=0.001*p1.low&&C_BlackBody(p1)&&C_WhiteBody(c))
    results.push({ name:'Tweezer Bottom', side:'BUY', score:70, desc:'Equal lows — buyers defending the level' });

  // Morning Star
  if (p2&&p1&&C_BlackBody(p2)&&C_LongBody(p2)&&C_SmallBody(p1)&&C_WhiteBody(c)&&c.close>=(C_BodyHi(p2)+C_BodyLo(p2))/2)
    results.push({ name:'Morning Star', side:'BUY', score:86, desc:'Classic 3-candle bullish reversal pattern' });

  // Morning Doji Star
  if (p2&&p1&&C_BlackBody(p2)&&C_LongBody(p2)&&C_Doji(p1)&&C_WhiteBody(c))
    results.push({ name:'Morning Doji Star', side:'BUY', score:88, desc:'High-conviction bullish reversal with doji hesitation' });

  // Dragonfly Doji
  if (C_Doji(c) && C_DnShadow(c)>2*C_Body(c) && C_UpShadow(c)<C_Body(c))
    results.push({ name:'Dragonfly Doji', side:'BUY', score:72, desc:'Bullish doji — sellers failed to sustain the sell-off' });

  // Three White Soldiers
  if (p2&&p1&&C_WhiteBody(p2)&&C_WhiteBody(p1)&&C_WhiteBody(c)&&p1.close>p2.close&&c.close>p1.close&&C_LongBody(p2)&&C_LongBody(p1)&&C_LongBody(c))
    results.push({ name:'Three White Soldiers', side:'BUY', score:90, desc:'Powerful 3-candle bullish continuation' });

  // Rising Three Methods
  if (p2&&p1&&p3&&C_WhiteBody(p3)&&C_BlackBody(p2)&&C_BlackBody(p1)&&C_WhiteBody(c)&&c.close>p3.close&&C_SmallBody(p2)&&C_SmallBody(p1))
    results.push({ name:'Rising Three Methods', side:'BUY', score:78, desc:'Bullish continuation after brief consolidation' });

  // Bullish Abandoned Baby
  if (p2&&p1&&C_BlackBody(p2)&&C_LongBody(p2)&&C_Doji(p1)&&gapDn(p2,p1)&&C_WhiteBody(c)&&gapUp(p1,c))
    results.push({ name:'Bullish Abandoned Baby', side:'BUY', score:92, desc:'Extremely rare high-conviction bullish reversal' });

  // Rising Window (Gap Up)
  if (p1&&c.low>p1.high)
    results.push({ name:'Rising Window', side:'BUY', score:74, desc:'Gap up — strong bullish sentiment, gap acts as support' });

  // Long Lower Shadow
  if (C_DnShadow(c)>2*C_Body(c)&&C_UpShadow(c)<0.5*C_DnShadow(c))
    results.push({ name:'Long Lower Shadow', side:'BUY', score:66, desc:'Buyers stepped in — strong lower wick rejection' });

  // ── BEARISH PATTERNS ──────────────────────────────────────────────────

  // Marubozu Black
  if (C_BlackBody(c)&&C_LongBody(c)&&C_NoUp(c)&&C_NoDn(c))
    results.push({ name:'Marubozu Black', side:'SELL', score:82, desc:'Strong bearish candle — full selling momentum' });

  // Hanging Man
  if (C_SmallBody(c)&&C_DnShadow(c)>=2*C_Body(c)&&C_UpShadow(c)<=0.1*C_Body(c)&&L>1&&p1.close>p1.open)
    results.push({ name:'Hanging Man', side:'SELL', score:72, desc:'Bearish warning at top — selling pressure emerging' });

  // Shooting Star
  if (C_SmallBody(c)&&C_UpShadow(c)>=2*C_Body(c)&&C_DnShadow(c)<=0.1*C_Body(c))
    results.push({ name:'Shooting Star', side:'SELL', score:76, desc:'Bearish reversal — bulls rejected at highs' });

  // Dark Cloud Cover
  if (p1&&C_WhiteBody(p1)&&C_LongBody(p1)&&C_BlackBody(c)&&c.open>p1.high&&c.close<(C_BodyHi(p1)+C_BodyLo(p1))/2&&c.close>p1.open)
    results.push({ name:'Dark Cloud Cover', side:'SELL', score:78, desc:'Bears penetrated prior bull candle — reversal warning' });

  // Bearish Engulfing
  if (p1&&C_WhiteBody(p1)&&C_BlackBody(c)&&c.open>=p1.close&&c.close<=p1.open)
    results.push({ name:'Bearish Engulfing', side:'SELL', score:80, desc:'Bulls fully engulfed — strong bearish momentum shift' });

  // Evening Star
  if (p2&&p1&&C_WhiteBody(p2)&&C_LongBody(p2)&&C_SmallBody(p1)&&C_BlackBody(c)&&c.close<=(C_BodyHi(p2)+C_BodyLo(p2))/2)
    results.push({ name:'Evening Star', side:'SELL', score:86, desc:'Classic 3-candle bearish reversal at top' });

  // Evening Doji Star
  if (p2&&p1&&C_WhiteBody(p2)&&C_LongBody(p2)&&C_Doji(p1)&&C_BlackBody(c))
    results.push({ name:'Evening Doji Star', side:'SELL', score:88, desc:'High-conviction bearish reversal with doji hesitation' });

  // Three Black Crows
  if (p2&&p1&&C_BlackBody(p2)&&C_BlackBody(p1)&&C_BlackBody(c)&&p1.close<p2.close&&c.close<p1.close&&C_LongBody(p2)&&C_LongBody(p1)&&C_LongBody(c))
    results.push({ name:'Three Black Crows', side:'SELL', score:90, desc:'Powerful 3-candle bearish continuation' });

  // Bearish Abandoned Baby
  if (p2&&p1&&C_WhiteBody(p2)&&C_LongBody(p2)&&C_Doji(p1)&&gapUp(p2,p1)&&C_BlackBody(c)&&gapDn(p1,c))
    results.push({ name:'Bearish Abandoned Baby', side:'SELL', score:92, desc:'Extremely rare high-conviction bearish reversal' });

  // Falling Window (Gap Down)
  if (p1&&c.high<p1.low)
    results.push({ name:'Falling Window', side:'SELL', score:74, desc:'Gap down — strong bearish sentiment, gap acts as resistance' });

  // Tweezer Top
  if (p1&&Math.abs(c.high-p1.high)<=0.001*p1.high&&C_WhiteBody(p1)&&C_BlackBody(c))
    results.push({ name:'Tweezer Top', side:'SELL', score:70, desc:'Equal highs — sellers defending the level' });

  // Gravestone Doji
  if (C_Doji(c)&&C_UpShadow(c)>2*C_Body(c)&&C_DnShadow(c)<C_Body(c))
    results.push({ name:'Gravestone Doji', side:'SELL', score:72, desc:'Bearish doji — buyers failed to sustain the rally' });

  // Long Upper Shadow
  if (C_UpShadow(c)>2*C_Body(c)&&C_DnShadow(c)<0.5*C_UpShadow(c))
    results.push({ name:'Long Upper Shadow', side:'SELL', score:66, desc:'Sellers rejected at highs — strong upper wick rejection' });

  // ── NEUTRAL PATTERNS ──────────────────────────────────────────────────

  // Doji
  if (C_Doji(c)&&!results.some(r=>r.name.includes('Doji')))
    results.push({ name:'Doji', side:'NEUTRAL', score:50, desc:'Indecision — market in balance, wait for confirmation' });

  return results;
}

// ─── Signal Generator (used by AI Signals page) ──────────────────────────
export function generateSignal(ltp, prices, volumes, strikeStep=50, isIndex=true) {
  if (!prices || prices.length < 20) return null;

  const closes   = prices;
  const n        = closes.length;
  const highs    = closes.map(v => v * (1 + Math.random()*0.003));
  const lows     = closes.map(v => v * (1 - Math.random()*0.003));
  const ohlcv    = closes.map((c,i)=>({ open:closes[Math.max(0,i-1)], high:highs[i], low:lows[i], close:c, vol:volumes[i]||1000000 }));

  const rsiArr   = rsi(closes, 14);
  const macData  = macd(closes, 12, 26, 9);
  const bbData   = bb(closes, 20, 2);
  const sma50Arr = sma(closes, Math.min(50,n));
  const sma200Arr= sma(closes, Math.min(200,n));
  const ema20Arr = ema(closes, 20);
  const ema50Arr = ema(closes, 50);
  const stoch    = stochastic(highs, lows, closes, 14, 3);
  const vwapArr  = vwap(ohlcv);
  const atrVal   = atr(ohlcv, 14);

  const L = n-1;
  const rsiVal   = rsiArr[L] || 50;
  const macdHist = macData.hist[L] || 0;
  const macdLine = macData.line[L] || 0;
  const macdSig  = macData.signal[L] || 0;
  const bbU      = bbData[L]?.upper || ltp*1.02;
  const bbL      = bbData[L]?.lower || ltp*0.98;
  const bbM      = bbData[L]?.mid   || ltp;
  const sma50    = sma50Arr[L]  || ltp;
  const sma200   = sma200Arr[L] || ltp;
  const ema20    = ema20Arr[L]  || ltp;
  const ema50    = ema50Arr[L]  || ltp;
  const stochK   = stoch.k[L]   || 50;
  const stochD   = stoch.d[L-stoch.d.length+stoch.k.filter(v=>v!=null).length] || 50;
  const vwapVal  = vwapArr[L]   || ltp;

  // Detect patterns
  const patterns = detectAllPatterns(ohlcv.slice(-10));

  // Score each condition
  const signals = [];
  if (rsiVal < 30) signals.push({ side:'BUY', weight:15, reason:'RSI Oversold (<30)' });
  else if (rsiVal > 70) signals.push({ side:'SELL', weight:15, reason:'RSI Overbought (>70)' });
  else if (rsiVal < 45) signals.push({ side:'BUY', weight:5, reason:'RSI Mildly Oversold' });
  else if (rsiVal > 55) signals.push({ side:'SELL', weight:5, reason:'RSI Mildly Overbought' });

  if (macdHist > 0 && macdLine > 0) signals.push({ side:'BUY', weight:12, reason:'MACD Bullish Crossover' });
  else if (macdHist < 0 && macdLine < 0) signals.push({ side:'SELL', weight:12, reason:'MACD Bearish Crossover' });
  else if (macdHist > 0) signals.push({ side:'BUY', weight:5, reason:'MACD Histogram Positive' });
  else signals.push({ side:'SELL', weight:5, reason:'MACD Histogram Negative' });

  if (ltp > sma50 && sma50 > sma200) signals.push({ side:'BUY', weight:18, reason:'Above SMA50 & SMA200 — Golden Cross' });
  else if (ltp < sma50 && sma50 < sma200) signals.push({ side:'SELL', weight:18, reason:'Below SMA50 & SMA200 — Death Cross' });
  else if (ltp > sma50) signals.push({ side:'BUY', weight:8, reason:'Price Above SMA50' });
  else signals.push({ side:'SELL', weight:8, reason:'Price Below SMA50' });

  if (ltp > ema20) signals.push({ side:'BUY', weight:6, reason:'Above EMA20' });
  else signals.push({ side:'SELL', weight:6, reason:'Below EMA20' });

  if (stochK < 20 && stochK > stochD) signals.push({ side:'BUY', weight:10, reason:'Stochastic Bullish Crossover (Oversold)' });
  else if (stochK > 80 && stochK < stochD) signals.push({ side:'SELL', weight:10, reason:'Stochastic Bearish Crossover (Overbought)' });

  if (ltp > vwapVal) signals.push({ side:'BUY', weight:6, reason:'Above VWAP' });
  else signals.push({ side:'SELL', weight:6, reason:'Below VWAP' });

  if (ltp < bbL) signals.push({ side:'BUY', weight:10, reason:'At/Below Bollinger Lower Band' });
  else if (ltp > bbU) signals.push({ side:'SELL', weight:10, reason:'At/Above Bollinger Upper Band' });

  // Add pattern signals
  patterns.forEach(p => {
    if (p.side === 'BUY') signals.push({ side:'BUY', weight: Math.round(p.score/10), reason: p.name });
    else if (p.side === 'SELL') signals.push({ side:'SELL', weight: Math.round(p.score/10), reason: p.name });
  });

  const buyScore  = signals.filter(s=>s.side==='BUY' ).reduce((s,v)=>s+v.weight, 0);
  const sellScore = signals.filter(s=>s.side==='SELL').reduce((s,v)=>s+v.weight, 0);
  const total = buyScore + sellScore || 1;

  let action, confidence, strength;
  const buyPct = buyScore/total*100;
  if (buyPct >= 65) { action='BUY'; confidence=Math.min(95,Math.round(buyPct)); strength=buyPct>=80?'STRONG':'MODERATE'; }
  else if (buyPct <= 35) { action='SELL'; confidence=Math.min(95,Math.round(100-buyPct)); strength=buyPct<=20?'STRONG':'MODERATE'; }
  else { action='HOLD'; confidence=Math.round(50+Math.abs(buyPct-50)); strength='WEAK'; }

  // Entry/SL/Targets using ATR
  const atrMult = isIndex ? 0.8 : 1.2;
  const entry = ltp;
  const stopLoss = action==='BUY' ? entry - atrVal*atrMult*1.2 : entry + atrVal*atrMult*1.2;
  const target1  = action==='BUY' ? entry + atrVal*atrMult*1.5 : entry - atrVal*atrMult*1.5;
  const target2  = action==='BUY' ? entry + atrVal*atrMult*2.5 : entry - atrVal*atrMult*2.5;
  const target3  = action==='BUY' ? entry + atrVal*atrMult*4.0 : entry - atrVal*atrMult*4.0;

  // Option recommendation
  const atm = Math.round(ltp/strikeStep)*strikeStep;
  const daysToExp = getDaysToExpiry('weekly');
  let optionRecommendation = null;
  if (action !== 'HOLD') {
    const type = action === 'BUY' ? 'CE' : 'PE';
    const strike = action === 'BUY' ? atm : atm;
    const approxDelta = 0.50;
    const ivPct = 0.16;
    const T = daysToExp/365;
    const optPremium = bsApprox(ltp, strike, T, 0.065, ivPct, type);
    const optTarget = optPremium + Math.abs(target1 - entry) * approxDelta;
    const optSL = Math.max(0.5, optPremium - Math.abs(entry - stopLoss) * approxDelta * 0.8);
    optionRecommendation = {
      type, strike, expiry: getExpiryLabel('weekly'),
      buyPrice: +optPremium.toFixed(1),
      sellPrice: +optTarget.toFixed(1),
      holdPrice: +optSL.toFixed(1),
      reason: `${action==='BUY'?'Bullish':'Bearish'} signal — ${strike}${type} exp ${getExpiryLabel('weekly')}. Entry ₹${optPremium.toFixed(1)}, Target ₹${optTarget.toFixed(1)}, SL ₹${optSL.toFixed(1)}. R:R = 1:${((optTarget-optPremium)/(optPremium-optSL)||0).toFixed(1)}.`,
    };
  }

  return {
    action, confidence, strength,
    entry: +entry.toFixed(2),
    stopLoss: +stopLoss.toFixed(2),
    target1: +target1.toFixed(2),
    target2: +target2.toFixed(2),
    target3: +target3.toFixed(2),
    rsi: rsiVal, stoch: { k: stochK, d: stochD },
    macd: { line: macdLine, signal: macdSig, histogram: macdHist },
    ema20, ema50, vwap: vwapVal, atr: atrVal,
    bb: { upper: bbU, mid: bbM, lower: bbL },
    sma50, sma200,
    patterns: patterns.map(p=>p.name),
    indicators: [...new Set(signals.map(s=>s.reason))].slice(0, 8),
    optionRecommendation,
  };
}

// ─── Black-Scholes (compact) ─────────────────────────────────────────────
function erf(x){
  const a=[.254829592,-.284496736,1.421413741,-1.453152027,1.061405429],p=.3275911;
  const s=x<0?-1:1, t=1/(1+p*Math.abs(x));
  return s*(1-((((a[4]*t+a[3])*t+a[2])*t+a[1])*t+a[0])*t*Math.exp(-x*x));
}
const N = x => 0.5*(1+erf(x/Math.SQRT2));
const Np= x => Math.exp(-x*x/2)/Math.sqrt(2*Math.PI);

export function bsApprox(S,K,T,r,σ,type='CE'){
  if(T<=0) return Math.max(0,type==='CE'?S-K:K-S);
  const d1=(Math.log(S/K)+(r+σ*σ/2)*T)/(σ*Math.sqrt(T)), d2=d1-σ*Math.sqrt(T);
  return type==='CE'?S*N(d1)-K*Math.exp(-r*T)*N(d2):K*Math.exp(-r*T)*N(-d2)-S*N(-d1);
}

export function calcGreeks(S,K,T,r,σ,type='CE'){
  if(T<=0) return{delta:type==='CE'?1:0,gamma:0,theta:0,vega:0,iv:σ*100};
  const d1=(Math.log(S/K)+(r+σ*σ/2)*T)/(σ*Math.sqrt(T)), d2=d1-σ*Math.sqrt(T), sqT=Math.sqrt(T);
  const delta=type==='CE'?N(d1):N(d1)-1;
  const gamma=Np(d1)/(S*σ*sqT);
  const theta=type==='CE'?(-S*Np(d1)*σ/(2*sqT)-r*K*Math.exp(-r*T)*N(d2))/365:(-S*Np(d1)*σ/(2*sqT)+r*K*Math.exp(-r*T)*N(-d2))/365;
  const vega=S*Np(d1)*sqT/100;
  return{delta:+delta.toFixed(3),gamma:+gamma.toFixed(5),theta:+theta.toFixed(2),vega:+vega.toFixed(2),iv:+(σ*100).toFixed(1)};
}

export function impliedVol(mktPx,S,K,T,r,type){
  if(T<=0||mktPx<=0) return 0.18;
  let σ=0.20;
  for(let i=0;i<60;i++){
    const px=bsApprox(S,K,T,r,σ,type);
    const d1=(Math.log(S/K)+(r+σ*σ/2)*T)/(σ*Math.sqrt(T));
    const vega=S*Np(d1)*Math.sqrt(T);
    const diff=px-mktPx;
    if(Math.abs(diff)<0.01) break;
    σ-=diff/(vega||0.01);
    σ=Math.min(Math.max(σ,0.01),5);
  }
  return σ;
}

// ─── Expiry Helpers ──────────────────────────────────────────────────────
export function getDaysToExpiry(type='weekly'){
  const ist = new Date(new Date().toLocaleString('en-US',{timeZone:'Asia/Kolkata'}));
  const day = ist.getDay(); // 0=Sun, 4=Thu
  if(type==='weekly'){
    const daysToThu = (4-day+7)%7 || 7;
    return Math.max(1, daysToThu);
  }
  // Monthly: last Thursday of current month
  const y=ist.getFullYear(), m=ist.getMonth();
  const lastDay=new Date(y,m+1,0);
  while(lastDay.getDay()!==4) lastDay.setDate(lastDay.getDate()-1);
  const diff=Math.ceil((lastDay-ist)/(1000*60*60*24));
  return diff<=0 ? getDaysToExpiryNextMonth() : diff;
}

function getDaysToExpiryNextMonth(){
  const ist=new Date(new Date().toLocaleString('en-US',{timeZone:'Asia/Kolkata'}));
  const y=ist.getFullYear(), m=ist.getMonth()+1;
  const lastDay=new Date(y,m+1,0);
  while(lastDay.getDay()!==4) lastDay.setDate(lastDay.getDate()-1);
  return Math.ceil((lastDay-ist)/(1000*60*60*24));
}

export function getExpiryLabel(type='weekly'){
  const ist=new Date(new Date().toLocaleString('en-US',{timeZone:'Asia/Kolkata'}));
  if(type==='weekly'){
    const d=new Date(ist);
    const dtt=(4-d.getDay()+7)%7||7;
    d.setDate(d.getDate()+dtt);
    return d.toLocaleDateString('en-IN',{day:'2-digit',month:'short',timeZone:'Asia/Kolkata'});
  }
  const y=ist.getFullYear(), m=ist.getMonth();
  const lastDay=new Date(y,m+1,0);
  while(lastDay.getDay()!==4) lastDay.setDate(lastDay.getDate()-1);
  return lastDay.toLocaleDateString('en-IN',{day:'2-digit',month:'short',timeZone:'Asia/Kolkata'});
}

// ─── Max Pain ────────────────────────────────────────────────────────────
export function calcMaxPain(rows){
  let minLoss=Infinity, maxPain=0;
  rows.forEach(row=>{
    let loss=0;
    rows.forEach(r=>{
      loss+=Math.max(0,row.strike-r.strike)*(r.ce?.oi||0);
      loss+=Math.max(0,r.strike-row.strike)*(r.pe?.oi||0);
    });
    if(loss<minLoss){minLoss=loss;maxPain=row.strike;}
  });
  return maxPain;
}

// ─── Build Option Chain (fallback when NSE blocked) ─────────────────────
export function buildOptionChain(spot, symbol, daysToExp=7){
  const step = { NIFTY:50,BANKNIFTY:100,FINNIFTY:50,MIDCPNIFTY:25,SENSEX:100,BANKEX:100 }[symbol]||5;
  const atm = Math.round(spot/step)*step;
  const T = Math.max(daysToExp/365, 0.003);
  const baseIV = 0.15 + (Math.random()-0.5)*0.02;
  const rows = [];
  for(let i=-10;i<=10;i++){
    const K = atm+i*step;
    const mono = (K-spot)/spot;
    const iv = Math.max(0.06, Math.min(0.8, baseIV - 0.08*mono + 0.03*mono*mono + (Math.random()-0.5)*0.006));
    const ceP = Math.max(0.05, bsApprox(spot,K,T,0.065,iv,'CE'));
    const peP = Math.max(0.05, bsApprox(spot,K,T,0.065,iv,'PE'));
    const ceG = calcGreeks(spot,K,T,0.065,iv,'CE');
    const peG = calcGreeks(spot,K,T,0.065,iv,'PE');
    const dist = Math.exp(-0.28*Math.abs(i));
    const baseOI = symbol.includes('NIFTY')||symbol==='SENSEX'||symbol==='BANKEX' ? 5000000 : 500000;
    const ceOI = Math.round(baseOI*(0.5+Math.random()*0.8)*dist/100)*100;
    const peOI = Math.round(baseOI*(0.6+Math.random()*0.8)*dist/100)*100;
    rows.push({
      strike:K, isATM:K===atm, isITM_CE:K<spot, isITM_PE:K>spot,
      ce:{px:+ceP.toFixed(2),oi:ceOI,chgOI:Math.round((Math.random()-0.4)*ceOI*0.1),
          vol:Math.round(ceOI*0.3),chgPct:+(Math.random()*30-15).toFixed(1),...ceG},
      pe:{px:+peP.toFixed(2),oi:peOI,chgOI:Math.round((Math.random()-0.4)*peOI*0.1),
          vol:Math.round(peOI*0.3),chgPct:+(Math.random()*30-15).toFixed(1),...peG},
    });
  }
  const totalCE = rows.reduce((s,r)=>s+r.ce.oi,0);
  const totalPE = rows.reduce((s,r)=>s+r.pe.oi,0);
  const pcr = totalPE/(totalCE||1);
  const maxPain = calcMaxPain(rows);
  const ceResist = rows.reduce((best,r)=>r.ce.oi>best.oi?{strike:r.strike,oi:r.ce.oi}:best,{strike:0,oi:0});
  const peSupport= rows.reduce((best,r)=>r.pe.oi>best.oi?{strike:r.strike,oi:r.pe.oi}:best,{strike:0,oi:0});
  return{rows,atm,pcr:+pcr.toFixed(2),maxPain,ceResist,peSupport,totalCE,totalPE,daysToExp};
}

// ─── Pivot Points ────────────────────────────────────────────────────────
export function calcPivots(h,l,c){
  const P=(h+l+c)/3;
  return{
    P,R1:2*P-l,R2:P+(h-l),R3:h+2*(P-l),
    S1:2*P-h,S2:P-(h-l),S3:l-2*(h-P),
    Fib236:c+(h-c)*.236, Fib382:c+(h-c)*.382,
    Fib500:c+(h-c)*.5,   Fib618:c+(h-c)*.618,
  };
}
